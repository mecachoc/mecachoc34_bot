from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler, MessageHandler, filters, ContextTypes

TOKEN = "TON_TOKEN_ICI"

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("📞 Appelle-moi", url="tel:+33771779604")],
        [InlineKeyboardButton("🛠 Voir mes prestations", callback_data='prestations')],
        [InlineKeyboardButton("📝 Demander un devis", callback_data='devis')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text(
        "🚗 Bienvenue chez MecaChoc34 !
Choisis une option ci-dessous 👇",
        reply_markup=reply_markup
    )

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if query.data == "prestations":
        await query.edit_message_text(text="""
🛠 *Prestations disponibles MecaChoc34* :

🔧 *Mécanique Générale* :
- Vidange + filtres
- Freinage complet
- Embrayage
- Distribution
- Suspension

🌀 *Turbo* :
- Remplacement turbo
- Diagnostic pression/fuite
- Turbo renforcé ou hybride

⚡ *Diagnostic / Électricité* :
- Diagnostic valise OBD2
- Batterie, démarreur, alternateur
- Optiques, LED, phares

💨 *Échappement / Pollution* :
- Ligne échappement
- Catalyseur, FAP, sonde lambda

📸 Photos avant/après sur demande
📞 Contact rapide possible en un clic
        """, parse_mode='Markdown')
    elif query.data == "devis":
        await query.edit_message_text("📝 Envoie-moi directement les infos de ton véhicule et les travaux souhaités. Je te réponds rapidement avec un devis 👍")

if __name__ == '__main__':
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(button_handler))
    app.run_polling()