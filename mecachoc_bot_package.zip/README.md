# MécaChoc34 Bot

Un bot Telegram pour promouvoir tes prestations mécaniques.

## Fonctionnalités
- Boutons interactifs (Appelle-moi, Voir prestations, Devis, Photos)
- Message d’accueil
- Hébergement gratuit via Render

## Fichiers
- `main.py` — le code du bot
- `requirements.txt` — dépendances
- `Procfile` — pour Render
- `.env.example` — à renommer `.env` et compléter avec ton token

## Déploiement
1. Upload sur GitHub
2. Connecte à [https://render.com](https://render.com)
3. Choisis "Web Service", relie ton GitHub, et ajoute `BOT_TOKEN` dans les variables d’environnement

Enjoy!
