import os
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackContext, CallbackQueryHandler

TOKEN = os.getenv("BOT_TOKEN")

async def start(update: Update, context: CallbackContext.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("📞 Appelle-moi", url="tel:+33771779604")],
        [InlineKeyboardButton("🛠 Voir mes prestations", callback_data='prestations')],
        [InlineKeyboardButton("📸 Voir photos avant/après", callback_data='photos')],
        [InlineKeyboardButton("📝 Demander un devis", callback_data='devis')]
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text("Bienvenue chez MécaChoc34 🚗🔧
Que veux-tu faire ?", reply_markup=reply_markup)

async def button_handler(update: Update, context: CallbackContext.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data
    if data == "prestations":
        await query.edit_message_text(text="🔧 Prestations proposées :
- Vidange
- Freins
- Embrayage
- Diagnostic
- Préparation moteur
Dispo sur Montpellier, Sète et alentours.")
    elif data == "photos":
        await query.edit_message_text(text="📸 Pour voir les photos avant/après, consulte notre Insta : https://instagram.com/mecachoc34")
    elif data == "devis":
        await query.edit_message_text(text="📝 Envoie-nous les infos suivantes :
- Modèle du véhicule
- Travaux souhaités
- Ville
Et on te répond au plus vite !")

def main():
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(button_handler))
    app.run_polling()

if __name__ == '__main__':
    main()
